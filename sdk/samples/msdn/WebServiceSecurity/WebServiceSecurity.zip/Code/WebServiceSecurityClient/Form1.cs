using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WebServiceSecurityClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(24, 40);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(16, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "textBox1";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(136, 77);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																							 this.textBox1,
																							 this.button1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// void Main merely loads the form.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// <summary>
		/// The button1_Click event handler runs when the button is clicked. The reference to the
		/// Greetings.asmx Web Service has already been set, so in this procedure you will 
		/// instantiate the Web Service and also create a NetworkCredential object.
		/// </summary>

		private void button1_Click(object sender, System.EventArgs e)
		{
			/// <summary>
			/// The NetworkCredential class is used to instantiate an object named myCred.
			/// This object will be passed to the Credentials property of the Web Service 
			/// object you create.</summary>
			System.Net.NetworkCredential myCred = new System.Net.NetworkCredential();
			/// <summary>
			/// myGreeting is the object you create that points to the Greetings Web Service.
			/// You may need to create a new Web Reference and change this line if the Web Service
			/// is not running on a local machine.</summary>
			localhost.Greetings myGreeting = new localhost.Greetings();
			/// <summary>
			/// Setting the UserName property of the NetworkCredential object. </summary>
			myCred.UserName="sue";
			/// <summary>
			/// Setting the Password property of the NetworkCredential object. </summary>
			myCred.Password="yukon";
			/// <summary>
			/// Here you set the Credentials property of the Web Service variable to the 
			/// NetworkCredential object you created earlier.</summary>
			myGreeting.Credentials=myCred;
			/// <summary>
			/// After the Credentials property is set, you call the Web Service method as you normally
			/// would, and the credential information is passed as part of the SOAP header.</summary>
			textBox1.Text=myGreeting.HelloWorld();
		}
	}
}
