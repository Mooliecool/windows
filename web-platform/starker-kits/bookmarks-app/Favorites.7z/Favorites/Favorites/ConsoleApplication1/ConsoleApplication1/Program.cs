﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add("", "Sites.xsd");

            Console.Write("Attempting to validate, ");
            XDocument custOrdDoc = XDocument.Load("Sites.xml");

            bool errors = false;
            custOrdDoc.Validate(schemas, (o, e) =>
            {
                Console.WriteLine("{0}", e.Message);
                errors = true;
            });
            Console.WriteLine("custOrdDoc {0}", errors ? "did not validate" : "validated");

            if (!errors)
            {
                // Join customers and orders, and create a new XML document with
                // a different shape.

                // The new document contains orders only for customers with a
                // CustomerID > '1'
                XElement custOrd = custOrdDoc.Element("Root");
                XElement newCustOrd = new XElement("Root",
                    from c in custOrd.Element("categories").Elements("category")
                    join o in custOrd.Element("sites").Elements("site")
                               on (string)c.Attribute("categoryID") equals
                                  (string)o.Element("categoryID")
                    where ((string)c.Attribute("categoryID")).CompareTo("1") > 0
                    select new XElement("site",
                        new XElement("categoryID", (string)c.Attribute("categoryID")),
                        new XElement("siteName", (string)c.Element("siteName")),
                        new XElement("URL", (string)c.Element("URL")),
                        new XElement("city", (string)o.Element("city")),
                        new XElement("state", (string)o.Element("state"))
                    )
                );
                Console.WriteLine(newCustOrd);
                Console.ReadLine();
            }

        }
    }
}
