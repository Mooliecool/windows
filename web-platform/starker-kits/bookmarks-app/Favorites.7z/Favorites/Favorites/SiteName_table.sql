USE Favorites 
CREATE TABLE SiteName
(
	SiteNameID		int	PRIMARY KEY,
	SiteName		varchar(30)
	
)
GO
