USE Favorites 
CREATE TABLE UrlName
(
	UrlID		int	PRIMARY KEY,
	UrlName		varchar(800)
	
)
GO