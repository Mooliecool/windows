﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq; 

namespace ConsoleLINQtoXML
{
    class Methods
    {
        public Methods()
        {



        }

        public void RetunValue()
        {
            var query = from c in XElement.Load("Customers.xml").Elements("Customers")
                        where (string)c.Element("CustomerID").Value == "ALFKI"
                        select c;

            foreach (var customer in query)
            {
                Console.WriteLine("{0} is available", customer.Element("ContactName").Value);

            }
            
        }



        public void GetItaly()
        {
            var custs = from c in XElement.Load("Customers.xml").Elements("Customers")
                        where c.Element("Country").Value == "Italy"
                        select c;

            // Execute the query 
            foreach (var customer in custs)
            {
                Console.WriteLine(customer);
            }


            //Pause the application 
            Console.ReadLine();

        }


    }
}
