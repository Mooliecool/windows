﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq; 


namespace ConsoleLINQtoXML
{
    class Program
    {
         public static void Main(string[] args)
        {
            Methods methods = new Methods();
            methods.RetunValue();

           
        }

       
    }
}
