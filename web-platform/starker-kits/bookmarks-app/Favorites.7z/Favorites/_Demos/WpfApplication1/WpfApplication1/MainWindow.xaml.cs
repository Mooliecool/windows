﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void RetunValue()
        {
            var query = from c in XElement.Load("Customers.xml").Elements("Customers")
                        where (string)c.Element("CustomerID").Value == "ALFKI"
                        select c;

            foreach (var customer in query)
            {
                textBlock1.Text = customer.Element("ContactName").Value;

            }
            

        }

        public void Count()
        {
            var query = from c in XElement.Load("Customers.xml").Elements("Customers")                       
                        select c;
            textBlock1.Text = query.Count().ToString();

        }

        public void GenerateRowColumns()
        {





        }

        public void GenerateTextBlocks()
        {
            int count;
            var query = from c in XElement.Load("Customers.xml").Elements("Customers")                       
                        select c;
            count = query.Count();          

           for (int i = 0; i <= query.Count(); i++)
           {
               TextBox txt = new TextBox();
               txt.Name = Guid.NewGuid().ToString().Substring(0, 2);
               txt.Height = 30;
               txt.Width = 150;
               txt.BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));

               grid.Children.Add(txt);              
           }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //RetunValue();
            Count();
            //GenerateTextBlocks();
        }
    }
}
