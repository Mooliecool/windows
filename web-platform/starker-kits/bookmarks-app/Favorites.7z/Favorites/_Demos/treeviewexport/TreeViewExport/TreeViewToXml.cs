using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;

namespace TreeViewExport
{
	/// <summary>
	/// Zusammenfassung f�r TreeViewToXml.
	/// </summary>
	public class TreeViewToXml
	{
        private static string xmlstring = "";
        private static StreamWriter sr;

		public TreeViewToXml()
		{
			
		}

        /// <summary>
        /// Exports the given TreeView to Xml and returns a string containing all tags
        /// </summary>
        /// <param name="tv">TreeView - This TreeView will be parsed</param>
        /// 
        public static void exportToXml(TreeView tv, string filename) 
        {
            sr = new StreamWriter(filename, false, System.Text.Encoding.UTF8);
            sr.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");

            IEnumerator ie = tv.Nodes.GetEnumerator();
            if (ie.MoveNext()) 
            {
                TreeNode tn = (TreeNode) ie.Current;
                sr.WriteLine("<" + tn.Text + ">");
                parseNode(tn);
            }

            sr.Close();
        }

        private static void parseNode(TreeNode tn) 
        {
            IEnumerator ie = tn.Nodes.GetEnumerator();

            string parentnode = "";

            parentnode = tn.Text;

            while (ie.MoveNext()) 
            {
                TreeNode ctn = (TreeNode) ie.Current;

                if (ctn.GetNodeCount(true) == 0) 
                {
                    sr.Write(ctn.Text);
                } 
                else 
                {
                    sr.Write("<" + ctn.Text + ">");
                }
                if (ctn.GetNodeCount(true) > 0) 
                {
                    parseNode(ctn);
                }
            }

            sr.Write("</" + parentnode + ">");
            sr.WriteLine("");

        }
	}
}
